<?php
include_once(__DIR__ . '/../connect.php');

// Check if the form is submitted for account deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $deleteId = $_POST['delete_id'];

    // Perform the delete operation
    $deleteSql = "DELETE FROM member WHERE id = $deleteId";
    if (mysqli_query($connect, $deleteSql)) {
        // No need to echo anything here if you don't want a success message
    } else {
        echo "Lỗi khi xóa tài khoản: " . mysqli_error($connect);
    }
} 
// Đóng kết nối
mysqli_close($connect);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Xóa Tài Khoản</title>
</head>
<body>

<form action="danhsachthanhvien.php" method="get">
    <button type="submit">Quay lại</button>
</form>

</body>
</html>